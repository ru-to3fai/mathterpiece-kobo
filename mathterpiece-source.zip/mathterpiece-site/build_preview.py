"""Pack the multipage draft into one file for viewing on a phone."""
from pathlib import Path
import base64
import json
import re
from urllib.parse import urljoin

root = Path(__file__).parent
asset_data = {}
for ext, mime in [('png', 'image/png'), ('jpg', 'image/jpeg'),
                  ('docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document')]:
    for file in (root / 'assets').glob(f'*.{ext}'):
        asset_data[file.name] = f'data:{mime};base64,' + base64.b64encode(file.read_bytes()).decode()
asset_data['geometry-formulas-original.pdf'] = 'data:application/pdf;base64,' + base64.b64encode((root / 'assets' / 'geometry-formulas-original.pdf').read_bytes()).decode()
pages = {}
for file in sorted(root.rglob('index.html')):
    key = file.relative_to(root).as_posix()
    html = file.read_text(encoding='utf-8')
    title = re.search(r'<title>(.*?)</title>', html, re.S).group(1)
    if key.endswith('trig-values/index.html'):
        for image in file.parent.glob('*.png'):
            data = base64.b64encode(image.read_bytes()).decode()
            html = html.replace(image.name, 'data:image/png;base64,' + data)
        pages[key] = {'title': title, 'quiz': html}
        continue
    if key.endswith('formula-board/index.html'):
        pages[key] = {'title': title, 'embed': html, 'back': 'math2/index.html'}
        continue
    body = re.search(r'<body>(.*?)</body>', html, re.S).group(1)
    body = re.sub(r'src="([^"]+\.(?:png|jpg))"', lambda match: 'src="__ASSET_' + Path(match.group(1)).name + '__"', body)
    def link(match):
        target = match.group(1)
        if target.startswith(('https:', 'http:', '#', 'mailto:')):
            return match.group(0)
        if target.endswith('.pdf'):
            return 'href="__ASSET_geometry-formulas-original.pdf__"'
        if target.endswith('.png'):
            return 'href="__ASSET_' + Path(target).name + '__"'
        if target.endswith(('.jpg', '.docx')):
            return 'href="__ASSET_' + Path(target).name + '__"'
        return 'href="#' + urljoin(key, target) + '"'
    body = re.sub(r'href="([^"]+)"', link, body)
    pages[key] = {'title': title, 'html': body}

css = (root / 'assets/style.css').read_text(encoding='utf-8')
data = json.dumps(pages, ensure_ascii=False).replace('<', '\\u003c')
assets = json.dumps(asset_data, ensure_ascii=False).replace('<', '\\u003c')
script = '''
const pages = JSON.parse(document.getElementById('pages').textContent);
const assets = JSON.parse(document.getElementById('assets').textContent);
function showPage() {
  const key = location.hash.slice(1) || 'index.html';
  const page = pages[key] || pages['index.html'];
  document.title = page.title;
  const app = document.getElementById('app');
  if (page.quiz || page.embed) {
    app.innerHTML = '<div class="wrap subhero"><a href="#' + (page.back || 'math2/trigonometry/index.html') + '">← 教材一覧へ</a></div>';
    const frame = document.createElement('iframe');
    frame.title = page.title;
    frame.style.cssText = 'display:block;width:100%;height:1500px;border:0;background:white';
    frame.srcdoc = page.quiz || page.embed;
    app.appendChild(frame);
    frame.addEventListener('load', () => {
      if (frame.contentDocument) frame.style.height = Math.max(800, frame.contentDocument.documentElement.scrollHeight + 30) + 'px';
    });
  } else {
    app.innerHTML = page.html.replace(/__ASSET_([A-Za-z0-9.-]+)__/g, (_, filename) => assets[filename]);
  }
  window.scrollTo(0, 0);
}
window.addEventListener('hashchange', showPage);
showPage();
'''
output = root.parent / 'mathterpiece-preview-fixed.html'
output.write_text(f'''<!doctype html>
<html lang="ja"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#193b5b"><title>Mathterpiece 工房</title><style>{css}</style></head>
<body><div id="app">{pages['index.html']['html']}</div>
<script id="pages" type="application/json">{data}</script>
<script id="assets" type="application/json">{assets}</script><script>{script}</script></body></html>''', encoding='utf-8')
print(output)
