from pathlib import Path
from html import escape
from geometry_lessons import LESSONS

root = Path(__file__).parent
subjects = [
    ("math1", "数学Ⅰ", "I"), ("math2", "数学Ⅱ", "II"),
    ("math3", "数学Ⅲ", "III"), ("matha", "数学A", "A"),
    ("mathb", "数学B", "B"), ("mathc", "数学C", "C"),
]
units = {
    "math1": [("algebra", "数と式"), ("sets", "集合と論証"), ("quadratic", "2次関数"), ("geometry", "図形と計量"), ("data", "データの分析")],
    "math2": [("proof", "式と証明"), ("complex", "複素数と方程式"), ("coordinate", "図形と方程式"), ("trigonometry", "三角関数"), ("exponential", "指数・対数関数"), ("calculus", "微分・積分")],
    "math3": [("limits", "極限"), ("differentiation", "微分法"), ("integration", "積分法")],
    "matha": [("counting", "場合の数と確率"), ("geometry", "図形の性質"), ("history", "数学と人間の活動")],
    "mathb": [("sequences", "数列"), ("statistics", "統計的な推測"), ("society", "数学と社会生活")],
    "mathc": [("vectors", "ベクトル"), ("curves", "平面上の曲線と複素数平面"), ("expression", "数学的な表現の工夫")],
}
portal = "https://sites.google.com/view/mathterpiece/%E3%83%9B%E3%83%BC%E3%83%A0"
tool = "https://ru-to3fai.github.io/tasukigake-unified/"
github_resources = {
    ("math1", "geometry"): [("三角錐ラボ", "三角錐を回して空間図形を確認。辺・面上の角・高さ・面積・体積の条件を指定し、対応する部分を確かめられます。", "triangular-pyramid-lab")],
    ("matha", "geometry"): [("三角錐ラボ", "三角錐を回して空間図形を確認。底面を切り替え、高さや辺・面・角のつながりを確かめられます。", "triangular-pyramid-lab")],
    ("math1", "quadratic"): [("解の公式｜係数から代入まで", "a・b・cを読み取り、2a、−b、b²、−4acを順に入力して公式への代入を練習します。", "kaino-kousiki")],
    ("math1", "data"): [("相関係数｜表埋めクイズ", "偏差や積などを表に埋め、相関係数を求める手順を練習できます。", "soukannkeisuu2")],
    ("math2", "exponential"): [("大小くらべトロッコ", "指数・対数の大小を比べて進むゲーム。指数と対数それぞれに基本・上級コースがあります。", "ookisa-torokko")],
    ("mathb", "sequences"): [("Σ公式フラッシュカード", "定数・k・k²の和をカードで確認。タップで答えを開き、上端が数値の問題も練習できます。", "sigma-formula-flashcards")],
}

def github_cards(key):
    return ''.join(f'<article class="resource"><div><span class="tag">学習ツール</span><h2>{escape(title)}</h2><p>{escape(detail)}</p></div><a class="open-button" href="https://ru-to3fai.github.io/{repo}/" target="_blank" rel="noopener">教材を開く ↗</a></article>' for title, detail, repo in github_resources.get(key, []))
subject_details = {
    "math1": "数と式・2次関数・図形と計量 など",
    "math2": "三角関数・指数と対数・微分と積分 など",
    "math3": "極限・微分法・積分法",
    "matha": "場合の数と確率・図形の性質 など",
    "mathb": "数列・統計的な推測 など",
    "mathc": "ベクトル・曲線と複素数平面 など",
}
clear_maps = {
    "complex": ("複素数と方程式", "clear-map-complex.jpg", "複素数・二次方程式・剰余の定理・因数定理・高次方程式のつながり"),
    "coordinate": ("図形と方程式", "clear-map-coordinate.jpg", "座標、直線、円、不等式で表す領域へ進む道筋"),
    "trigonometry": ("三角関数", "clear-map-trigonometry.jpg", "三角比から単位円、加法定理、グラフへ進む道筋"),
}

def map_resource(unit_slug):
    name, _, detail = clear_maps[unit_slug]
    return f'''<article class="resource"><div><span class="tag">学習マップ</span>
      <h2>数学クリアマップ｜{name}</h2><p>前提知識と学習の流れ、関連する分野を１枚で見渡せます。{detail}。</p></div>
      <a class="open-button" href="clear-map/index.html">マップを見る →</a></article>'''

def page(title, description, body, prefix=""):
    links = "".join(f'<a href="{prefix}{slug}/index.html"{(" aria-current=\"page\"" if title == name else "")}>{name}</a>' for slug, name, _ in subjects)
    nav = f'''<nav class="wrap main-nav" aria-label="科目別メニュー">
      <a href="{prefix}index.html"{(' aria-current="page"' if title == 'ホーム' else '')}>ホーム</a>{links}
    </nav>''' if title != "ホーム" else ""
    stylesheet = f'<style>{(root / "assets/style.css").read_text(encoding="utf-8")}</style>'
    return f'''<!doctype html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#193b5b">
  <meta name="description" content="{escape(description)}">
  <title>{escape(title)} | Mathterpiece 工房</title>
  {stylesheet}
</head>
<body>
  <header class="site-header">
    <div class="wrap header-inner">
      <a class="brand" href="{prefix}index.html" aria-label="Mathterpiece 工房のホーム">
        <span class="brand-mark" aria-hidden="true">m</span><span>Mathterpiece 工房<small>自作教材・学習ツール</small></span>
      </a>
      <a class="portal-link" href="{portal}">数学サイトの案内所 ↗</a>
    </div>
    {nav}
  </header>
  <main id="main">{body}</main>
  <footer class="site-footer"><div class="wrap footer-inner">
    <p>Mathterpiece 工房｜自作教材・学習ツール</p>
    <a href="{portal}">外部の教材も探す：数学教材集の欠片 ↗</a>
  </div></footer>
</body>
</html>
'''

cards = "".join(f'''<a class="subject-card" href="{slug}/index.html">
  <span class="number" aria-hidden="true">{roman}</span>
  <strong>{name}</strong>
  <span class="detail">{subject_details[slug]}</span>
  <span class="go">教材を見る →</span>
</a>''' for slug, name, roman in subjects)
home = f'''
  <section class="wrap hero" aria-labelledby="page-title">
    <p class="eyebrow">LEARN BY DOING</p>
    <h1 id="page-title">数学の教材を、<br>分野から探す。</h1>
    <p class="intro">Mathterpiece 工房の自作教材をまとめています。学びたい分野を選び、練習ツールやプリントを開いてください。</p>
    <span class="hero-note"><span class="dot" aria-hidden="true"></span>教材を少しずつ追加しています</span>
  </section>
  <section class="wrap section" aria-labelledby="subjects-title">
    <div class="section-heading"><h2 id="subjects-title">分野から探す</h2><p>科目を選ぶと、単元の一覧に進めます。</p></div>
    <nav class="subject-grid" aria-label="数学の科目">{cards}</nav>
  </section>
  <section class="wrap section"><div class="portal-panel">
    <div><h2>外部の数学サイトも探す</h2><p>良質な数学サイトや教材の案内は、Google Sitesの「数学教材集の欠片」にまとめています。</p></div>
    <a class="outline-button" href="{portal}">総合案内を見る ↗</a>
  </div></section>
'''
(root / "index.html").write_text(page("ホーム", "Mathterpiece 工房の自作数学教材を数学Ⅰ・Ⅱ・Ⅲ・A・B・Cから探せます。", home), encoding="utf-8")

for slug, name, _ in subjects:
    contents = '<h2>単元を選ぶ</h2><ul class="unit-list">' + ''.join(
        f'<li><a href="{unit_slug}/index.html">{unit_name} <span aria-hidden="true">→</span></a></li>'
        for unit_slug, unit_name in units[slug]
    ) + '</ul>'
    if slug == "math2":
        contents += '''<article class="resource subject-tool"><div><span class="tag">数学Ⅱ 全体の学習ツール</span>
          <h2>電子公式ボード</h2><p>図形と方程式・三角関数・指数と対数・微分・積分の公式を確認できます。</p></div>
          <a class="open-button" href="formula-board/index.html">公式を開く →</a></article>'''
    body = f'''
  <section class="wrap subhero"><a class="breadcrumb" href="../index.html">ホーム</a><span aria-hidden="true"> / </span><span>{name}</span>
    <h1>{name}</h1><p class="intro">単元を選ぶと、教材・学習ツールの一覧に進めます。</p>
  </section>
  <div class="wrap section"><div class="course">{contents}</div></div>
'''
    folder = root / slug
    folder.mkdir(exist_ok=True)
    (folder / "index.html").write_text(page(name, f"{name}の自作数学教材・学習ツール。", body, "../"), encoding="utf-8")

    for unit_slug, unit_name in units[slug]:
        if (slug, unit_slug) == ("math1", "algebra"):
            resources = f'''<article class="resource"><div><span class="tag">学習ツール</span>
              <h2>たすきがけの因数分解｜初級・ランダム・上級</h2>
              <p>斜めの積とその和を確かめながら練習できます。入口で３つのコースを選べます。</p></div>
              <a class="open-button" href="{tool}">練習を始める ↗</a></article>'''
        elif (slug, unit_slug) == ("math2", "trigonometry"):
            resources = map_resource("trigonometry") + '''<article class="resource"><div><span class="tag">学習ツール</span>
              <h2>三角関数の値クイズ</h2>
              <p>ラジアンで表した角の sin・cos・tan の値を選択式で練習できます。単位円のヒント付きです。</p></div>
              <a class="open-button" href="https://ru-to3fai.github.io/sannkakukannsuu/">クイズを始める ↗</a></article>'''
        elif (slug, unit_slug) == ("math2", "coordinate"):
            resources = map_resource("coordinate") + '''<article class="resource"><div><span class="tag">公式の使い方</span>
              <h2>数直線上の内分点</h2>
              <p>赤と青の矢印を追い、数字が式のどこへ入るかを確かめます。</p></div>
              <a class="open-button" href="section-point/index.html">教材を見る →</a></article>'''
            resources += ''.join(f'''<article class="resource"><div><span class="tag">公式の使い方</span>
              <h2>{escape(item['title'])}</h2><p>{escape(item['intro'])}</p></div>
              <a class="open-button" href="{item['slug']}/index.html">教材を見る →</a></article>''' for item in LESSONS)
            resources += '''<article class="resource"><div><span class="tag">元教材</span>
              <h2>手書きの教材・全15ページ</h2><p>例題と練習をまとめて見たり印刷したりできます。</p></div>
              <a class="open-button" href="../../assets/geometry-formulas-original.pdf">PDFを開く ↗</a></article>'''
        elif (slug, unit_slug) == ("math2", "complex"):
            resources = map_resource("complex")
        elif (slug, unit_slug) == ("math2", "exponential"):
            resources = '''<article class="resource"><div><span class="tag">100問ドリル · Word</span>
              <h2>対数の100問計算ドリル</h2><p>４段階の計算練習。印刷や書き換えに使えるWord教材です。</p></div>
              <a class="open-button" href="../../assets/drill-log-calculation-100.docx" download>Wordをダウンロード ↓</a></article>
              <article class="resource"><div><span class="tag">100問ドリル · Word</span>
              <h2>指数対数の大小100問ドリル</h2><p>指数と対数の大小を比較する４段階の練習。Word教材です。</p></div>
              <a class="open-button" href="../../assets/drill-exponent-log-comparison-100.docx" download>Wordをダウンロード ↓</a></article>'''
        else:
            resources = '<p class="muted">教材の準備中です。完成した教材をこの単元に追加します。</p>'
        if (slug, unit_slug) in github_resources:
            if '教材の準備中' in resources:
                resources = ''
            resources += github_cards((slug, unit_slug))
        unit_body = f'''
  <section class="wrap subhero"><a class="breadcrumb" href="../../index.html">ホーム</a><span aria-hidden="true"> / </span>
    <a class="breadcrumb" href="../index.html">{name}</a><span aria-hidden="true"> / </span><span>{unit_name}</span>
    <h1>{unit_name}</h1><p class="intro">{name}の「{unit_name}」に関する自作教材です。</p>
  </section>
  <div class="wrap section"><div class="course">{resources}</div></div>
'''
        unit_folder = folder / unit_slug
        unit_folder.mkdir(exist_ok=True)
        (unit_folder / "index.html").write_text(page(f"{unit_name} | {name}", f"{name}・{unit_name}の自作数学教材。", unit_body, "../../"), encoding="utf-8")

lesson = '''
  <section class="wrap subhero lesson-intro">
    <a class="breadcrumb" href="../../../index.html">ホーム</a><span aria-hidden="true"> / </span>
    <a class="breadcrumb" href="../../index.html">数学Ⅱ</a><span aria-hidden="true"> / </span>
    <a class="breadcrumb" href="../index.html">図形と方程式</a><span aria-hidden="true"> / </span><span>内分点</span>
    <p class="eyebrow">公式の使い方 · 01</p>
    <h1>数直線上の内分点</h1>
    <p class="intro">２点の座標と比が分かったとき、内分点の座標を求めます。色をたどって、数字の置き場所を確かめましょう。</p>
  </section>
  <div class="wrap lesson-stack">
    <section class="lesson-panel" aria-labelledby="original-diagram-title">
      <span class="lesson-step">01 · 元教材の図を読む</span>
      <h2 id="original-diagram-title">どの数が、式のどこへ行く？</h2>
      <p>元教材の手書きの矢印をたどってみましょう。<span class="blue-text">青い 1 と 3</span> はそのまま分子の座標へ。<span class="red-text">赤い 5 と 6</span> は交差して分子に入り、分母には 5 ＋ 6 と並びます。</p>
      <figure class="annotated-figure">
        <div class="diagram-scroll" tabindex="0" aria-label="元教材の例題の図。横にスクロールして矢印を追えます">
          <div class="diagram-crop diagram-example"><img src="../../../assets/section-point-original-page.png" width="1392" height="1800" alt="元教材の例題。A(1)の1とB(3)の3から青い矢印が式の1と3へつながる。5対6からの赤い矢印と交差線は、分子の6掛ける1足す5掛ける3、分母の5足す6への対応を示す。"></div>
        </div>
        <figcaption>図を左右に動かして、青と赤の矢印を追えます。<a href="../../../assets/section-point-original-page.png">元の１ページを大きく見る ↗</a></figcaption>
      </figure>
    </section>
    <section class="lesson-panel" aria-labelledby="situation-title">
      <span class="lesson-step">02 · いつ使う？</span>
      <h2 id="situation-title">線分を「何対何」に分ける点を求める</h2>
      <p>点 <span class="blue-text">A(a)</span> と <span class="blue-text">B(b)</span> の間に点 P があり、<span class="red-text">AP : PB = m : n</span> のときの P の座標です。</p>
      <div class="line-diagram" role="img" aria-label="左から A、P、B が並び、AP が m、PB が n の数直線">
        <div class="line-ratios"><span class="red-text">m</span><span class="red-text">n</span></div>
        <div class="line-points"><span class="point">A</span><span class="point focus">P</span><span class="point">B</span></div>
        <div class="line-coords"><span class="blue-text">a</span><span>?</span><span class="blue-text">b</span></div>
      </div>
    </section>
    <section class="lesson-panel" aria-labelledby="formula-title">
      <span class="lesson-step">03 · 数字の置き方</span>
      <h2 id="formula-title">上は交差、下は比の和</h2>
      <p>分子では、A の座標には<span class="red-text">反対側の n</span>、B の座標には<span class="red-text">反対側の m</span>を掛けます。</p>
      <div class="formula-board" aria-label="内分点の座標の公式">
        <span class="formula-leading">P の座標 = </span>
        <span class="fraction"><span class="numerator"><span class="red-text">n</span> × <span class="blue-text">a</span> ＋ <span class="red-text">m</span> × <span class="blue-text">b</span></span><span class="denominator"><span class="red-text">m</span> ＋ <span class="red-text">n</span></span></span>
      </div>
      <p class="lesson-tip">覚える目印：<strong>座標には反対側の比を掛ける。</strong></p>
    </section>
    <section class="lesson-panel" aria-labelledby="example-title">
      <span class="lesson-step">04 · 例で確かめる</span>
      <h2 id="example-title">A(1)、B(3) を 5 : 6 に内分</h2>
      <p><span class="blue-text">A の 1</span> には <span class="red-text">6</span>、<span class="blue-text">B の 3</span> には <span class="red-text">5</span> を掛けます。</p>
      <div class="formula-board worked-formula" aria-label="計算例：6かける1たす5かける3、割る5たす6、イコール11分の21">
        <span class="fraction"><span class="numerator"><span class="red-text">6</span> × <span class="blue-text">1</span> ＋ <span class="red-text">5</span> × <span class="blue-text">3</span></span><span class="denominator"><span class="red-text">5</span> ＋ <span class="red-text">6</span></span></span>
        <span>＝</span><span class="fraction"><span class="numerator">21</span><span class="denominator">11</span></span>
      </div>
      <p class="lesson-tip">5 : 6 の点 P は、A と B の間で A に少し近い位置。答えの 21/11 ≒ 1.91 も 1 と 3 の間です。</p>
    </section>
    <section class="lesson-panel" aria-labelledby="practice-title">
      <span class="lesson-step">05 · 自分でやってみる</span>
      <h2 id="practice-title">練習</h2>
      <div class="practice-item"><h3>練習１</h3><p>点 A(4)、B(2) を 2 : 3 に内分する点の座標は？</p>
        <p class="practice-prompt">元教材の空欄に、矢印をたどりながら数字を入れてみましょう。</p>
        <figure class="annotated-figure"><div class="diagram-scroll" tabindex="0" aria-label="元教材の練習１。横にスクロールして矢印と空欄を追えます"><div class="diagram-crop diagram-practice"><img src="../../../assets/section-point-original-page.png" width="1392" height="1800" alt="練習１の書き込み図。A(4)とB(2)の座標から青い矢印が分子の青い丸へ、2対3から赤い矢印と交差線が式の赤い空欄へつながる。"></div></div><figcaption>青い丸と赤い枠を埋めてから、答えを開いてください。</figcaption></figure>
        <details><summary>式と答えを見る</summary><p><span class="fraction"><span class="numerator">3 × 4 ＋ 2 × 2</span><span class="denominator">2 ＋ 3</span></span> ＝ <span class="fraction"><span class="numerator">16</span><span class="denominator">5</span></span></p><p>A の 4 には反対側の 3 を掛けます。</p></details>
      </div>
      <div class="practice-item"><h3>練習２</h3><p>点 A(−1)、B(3) を 3 : 1 に内分する点の座標は？</p>
        <details><summary>式と答えを見る</summary><p><span class="fraction"><span class="numerator">1 × (−1) ＋ 3 × 3</span><span class="denominator">3 ＋ 1</span></span> ＝ 2</p><p>答えの 2 は −1 と 3 の間にあります。</p></details>
      </div>
    </section>
    <aside class="source-note"><div><h2>元の教材も見る</h2><p>手書きの赤と青の矢印を含む、全15ページのPDFです。印刷して練習するときにも使えます。</p></div>
      <a class="outline-button" href="../../../assets/geometry-formulas-original.pdf">PDFを開く ↗</a></aside>
  </div>
'''
lesson_folder = root / "math2" / "coordinate" / "section-point"
lesson_folder.mkdir(parents=True, exist_ok=True)
(lesson_folder / "index.html").write_text(page("数直線上の内分点 | 公式の使い方", "数直線上の内分点の公式を例と練習問題で学ぶ。", lesson, "../../../"), encoding="utf-8")

def figure(item, kind):
    image = f"geometry-page-{item['page']:02d}.png"
    if kind == "example":
        offset, height = 0, item['ex_height']
        label = "元教材の例題の図。色のついた数字から式の対応する場所までの矢印。"
    else:
        offset, height = -item['practice_top'], item['practice_height']
        label = "元教材の練習１。色分けされた数字と、矢印の先にある空欄。"
    return f'''<figure class="annotated-figure">
      <div class="diagram-scroll" tabindex="0" aria-label="{label} 横にスクロールして図を追えます">
        <div class="diagram-crop diagram-window" style="--crop-top:{offset}px;--crop-height:{height}px">
          <img src="../../../assets/{image}" width="1392" height="1800" alt="{label}">
        </div>
      </div>
      <figcaption>図を左右に動かして矢印を追えます。<a href="../../../assets/{image}">この教材の元ページを大きく見る ↗</a></figcaption>
    </figure>'''

for item in LESSONS:
    title = escape(item['title'])
    additional_practice = f'''<div class="practice-item"><h3>練習２</h3><p>{escape(item['p2'])}</p>
      <details><summary>式と答えを見る</summary><p class="worked-math">{escape(item['a2'])}</p></details></div>''' if item['p2'] else ''
    body = f'''
      <section class="wrap subhero lesson-intro">
        <a class="breadcrumb" href="../../../index.html">ホーム</a><span aria-hidden="true"> / </span>
        <a class="breadcrumb" href="../../index.html">数学Ⅱ</a><span aria-hidden="true"> / </span>
        <a class="breadcrumb" href="../index.html">図形と方程式</a><span aria-hidden="true"> / </span><span>{title}</span>
        <p class="eyebrow">公式の使い方 · {item['page']:02d}</p>
        <h1>{title}</h1><p class="intro">{escape(item['intro'])}</p>
      </section>
      <div class="wrap lesson-stack">
        <section class="lesson-panel"><span class="lesson-step">01 · 元教材の図を読む</span>
          <h2>数字から式への矢印を追う</h2>
          <p>{escape(item['mapping'])}</p>{figure(item, 'example')}
        </section>
        <section class="lesson-panel"><span class="lesson-step">02 · 式を整理する</span>
          <h2>図で追った数字を式にする</h2>
          <p>{escape(item['rule'])}</p>
          <div class="formula-board worked-math">{escape(item['example'])}</div>
        </section>
        <section class="lesson-panel"><span class="lesson-step">03 · 自分でやってみる</span><h2>練習</h2>
          <div class="practice-item"><h3>練習１</h3><p>{escape(item['p1'])}</p>
            <p class="practice-prompt">元教材の矢印と空欄を見てから、答えを開いてください。</p>
            {figure(item, 'practice')}
            <details><summary>式と答えを見る</summary><p class="worked-math">{escape(item['a1'])}</p></details>
          </div>{additional_practice}
        </section>
        <aside class="source-note"><div><h2>元の教材も見る</h2><p>このページの図は、元教材からそのまま掲載しています。全体版は図形と方程式の一覧から開けます。</p></div>
          <a class="outline-button" href="../index.html">教材一覧へ戻る →</a></aside>
      </div>'''
    folder = root / "math2" / "coordinate" / item['slug']
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "index.html").write_text(page(f"{item['title']} | 公式の使い方", f"{item['title']}。元教材の色分けした矢印を使って式の作り方を学ぶ。", body, "../../../"), encoding="utf-8")

for unit_slug, (unit_name, image, detail) in clear_maps.items():
    map_body = f'''
      <section class="wrap subhero lesson-intro">
        <a class="breadcrumb" href="../../../index.html">ホーム</a><span aria-hidden="true"> / </span>
        <a class="breadcrumb" href="../../index.html">数学Ⅱ</a><span aria-hidden="true"> / </span>
        <a class="breadcrumb" href="../index.html">{unit_name}</a><span aria-hidden="true"> / </span><span>数学クリアマップ</span>
        <p class="eyebrow">LEARNING MAP</p><h1>数学クリアマップ｜{unit_name}</h1>
        <p class="intro">{detail}を、前提知識・単元の中身・次につながる分野から見渡せます。</p>
      </section>
      <section class="wrap lesson-stack"><div class="lesson-panel">
        <h2>学習の全体像</h2><p>スマートフォンでは左右に動かして拡大図を確認できます。</p>
        <figure class="map-figure"><div class="map-scroll" tabindex="0" aria-label="{unit_name}の学習マップ。左右にスクロールできます">
          <img src="../../../assets/{image}" width="1536" height="864" alt="{unit_name}の数学クリアマップ。前提知識、単元の中身、つながる分野、活用・見方を矢印で整理した図。">
        </div><figcaption><a href="../../../assets/{image}">図だけを大きく開く ↗</a></figcaption></figure>
      </div><a class="outline-button" href="../index.html">{unit_name}の教材一覧へ戻る →</a></section>'''
    map_folder = root / "math2" / unit_slug / "clear-map"
    map_folder.mkdir(parents=True, exist_ok=True)
    (map_folder / "index.html").write_text(page(f"数学クリアマップ｜{unit_name}", f"{unit_name}の学習のつながりを図で示す数学クリアマップ。", map_body, "../../../"), encoding="utf-8")
